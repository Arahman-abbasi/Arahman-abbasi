//Task 1.1
// Abdur Rahman
// G01414666
// Cs-211

public class Animal {
    private boolean nocturnal;
    private String type;
    private String name;

    public Animal(boolean nocturnal, String type, String name) {

        this.nocturnal = nocturnal;
        this.type = type;
        this.name = name;
    }

    public void printFeed() {
        System.out.println("Chomp Chomp");
    }

    // public String getName() {
    // return name;
    // }

    // public String getType() {
    // return type;
    // }

    // public Boolean getNocturnal() {
    // return nocturnal;
    // }

    public void printSleepInfo() {
        if (nocturnal) {
            System.out.println(this.type + "s during the day");
        } else {
            System.out.println(this.type + "s during the night");
        }
    }

    public void printInfo() {
        System.out.println(this.name + "is a(n)" + this.type + ".");
    }

    public void printRoam() {
        System.out.println(this.name + " walks around.");
    }

}