package app;

import taskmanager.Task;
import taskmanager.TaskList;

public class TaskManagerApp {
    public static void main(String[] args) {
        if (args.length < 1) {
            System.out.println("Max Task List Size Not Given");
            return;
        }
        int taskListSize = Integer.parseInt(args[0]);

        TaskList taskList = new TaskList(taskListSize);

        Task t1 = new Task(Integer.parseInt(args[1]), args[2], args[3]);
        Task t2 = new Task(2, "Task2", "this is a newer task");
        taskList.addTask(t1);
        taskList.addTask(t2);

        taskList.getAllTasks();

    }
}

// /* This is the constructor*
// @param capacity
// This is used to initialize the Tasklist */

// public TaskList(int capacity) {
// tasks = new Task[capacity]:
// size= 0;
// }