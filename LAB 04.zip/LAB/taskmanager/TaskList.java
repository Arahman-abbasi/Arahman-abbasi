// package taskmanager;

// public class TaskList {
//     private Task[] tasks;
//     private int size;

//     public TaskList(int capacity){
//     tasks = new Task [capacity];
//     size = 0;

// }

// public void addTask (Task task){
//     if (size < tasks.length) {
//         task [size++] = task;
//     }else {
//         System.out.println("Task list is full.Cannot add more tasks.");
//     }

// }

// public task[] getAllTasks() {
//  Task[]allTasks = new Task [size];
//  System.arraycopy(tasks,0, allTasks ,0, size);
//  for(int i = 0; i<allTasks.length ; i++){
//     System.out.println(allTasks[i].toString());
//  }
//  return allTasks;
// }
// }

package taskmanager;

public class TaskList {
    private Task[] tasks;
    private int size;

    /**
     * This is the constructor for TaskList.
     * It initializes the task list with the given capacity.
     * 
     * @param capacity The initial capacity of the task list.
     */
    public TaskList(int capacity) {
        tasks = new Task[capacity];
        size = 0;
    }

    /**
     * Adds a task to the task list.
     * 
     * @param task The task to add.
     */
    public void addTask(Task task) {
        if (size < tasks.length) {
            tasks[size++] = task;
        } else {
            System.out.println("Task list is full. Cannot add more tasks.");
        }
    }

    /**
     * Retrieves all tasks in the task list.
     * 
     * @return An array containing all tasks in the task list.
     */
    public Task[] getAllTasks() {
        Task[] allTasks = new Task[size];
        System.arraycopy(tasks, 0, allTasks, 0, size);
        for (int i = 0; i < allTasks.length; i++) {
            System.out.println(allTasks[i].toString());
        }
        return allTasks;
    }
}
