public class ShapeAnalyzer {
    private static final Object EMPTY_PROPERTY = new Object();

    public static Machine analyze(String json) {
        // try this as you start exploring the project: use null for refrence types, and
        // data for primitives.
        String[][] entries = parseEntries(json);
        String kind = reifyKind(entries);
        Object[] properties = reifyProperties(entries);
        boolean humanConstrained = SystemWhole.isHumanoid(properties);

        Machine machine = new Machine(kind, properties, humanConstrained);

        return machine;
    }

    public static String[][] parseEntries(String flatJson) {
        // Apply regex to tokenize the string.
        String[] tokens = flatJson.split("[{},\":]+");

        String[] kind = { "kind", null };
        String[] bodyType = { "bodyType", null };
        String[] faceType = { "faceType", null };
        String[] material = { "material", null };
        String[] function = { "function", null };
        String[] reverie = { "reverie", null };

        for (int i = 0; i < tokens.length; i++) {
            if ("kind".equals(tokens[i])) {
                kind = new String[] { "kind", tokens[i + 2] };
            } else if ("bodyType".equals(tokens[i])) {
                bodyType = new String[] { "bodyType", tokens[i + 2] };
            } else if ("faceType".equals(tokens[i])) {
                faceType = new String[] { "faceType", tokens[i + 2] };
            } else if ("material".equals(tokens[i])) {
                material = new String[] { "material", tokens[i + 2] };
            } else if ("function".equals(tokens[i])) {
                function = new String[] { "function", tokens[i + 2] };
            } else if ("reverie".equals(tokens[i])) {
                reverie = new String[] { "reverie", tokens[i + 2] };
            }
        }

        String[][] entries = { kind, bodyType, faceType, material, function, reverie };

        return entries;

    }

    public static String reifyKind(String[][] entries) {

        if (entries[0][0].equals("kind")) {
            return entries[0][1];
        }

        return null;
    }

    public static Object[] reifyProperties(String[][] entries) {
        int i = 0;

        Object[] properties = new Object[entries.length - 1];

        for (String[] entry : entries) {
            if (entry[0] == "kind")
                continue;

            PartState prop = new PartState(entry[0], inferObject(entry[1]));
            properties[i++] = prop;
        }

        return properties;
    }

    public static boolean isDigit(char c) {
        return c >= '0' && c <= '9';
    }

    public static boolean hasNonNumbers(String value) {
        for (char c : value.toCharArray()) {
            if (!isDigit(c) && c != '.' && c != '_') {
                return true;
            }
        }
        return false;
    }

    public static Object inferObject(String value) {
        if (value == null || value.isEmpty()) {
            return EMPTY_PROPERTY;
        } else if (hasNonNumbers(value) || value.contains("_")) {
            return value;
        } else if (value.contains(".")) {
            return Double.parseDouble(value);
        } else {
            return Integer.parseInt(value);
        }
    }

}