
// DO NOT INCLUDE THIS IMPORT WHEN SENT FOR GRADING, THIS IS HERE TO HELP YOU DEBUG THE PROGRAM STATE
// import java.util.Arrays;

public class SystemWhole {
    public static String[] emergences; // To store JSON strings representing emergences
    public static Machine[] parts; // To store Machine objects directly as an array

    public static void main(String[] args) {
        // Sample JSON strings representing different "emergences"
        String[] emergences = {
                "{\"kind\": \"Humanoid\", \"bodyType\": \"physical\", \"faceType\": \"anthropomorphic\", \"reverie\": \"mechatypical\"}",
                "{\"kind\": \"Humanoid\", \"bodyType\": \"physical\", \"faceType\": \"anthropomorphic\", \"reverie\": \"biotypical\"}",
                "{\"kind\": \"Robot\", \"material\": \"metal\", \"function\": \"industrial\"}",
                "{\"kind\": \"Humanoid\", \"bodyType\": \"physical\", \"faceType\": \"anthropomorphic\"}"
        };

        // Parse the emergences and set them to the SystemWhole state
        emergencesFromPhenomena(emergences);
        // Analyze the shapes based on the set emergences
        reifyFrameOfReference();
        // System.out.println("Prelude of the Rise of the Machines: " +
        // Arrays.deepToString(parts));
        parts[0].emergeFromLimitations();
        // Track humanoid machines and identify singularities
        Machine[] singularities = trackSingularityMachines();
        // System.out.println("Singularities: " + Arrays.deepToString(singularities));
    }

    // Visibility modifiers: public vs private
    public static void emergencesFromPhenomena(String[] emergences) {
        // Class and Object State: static vs this
        SystemWhole.emergences = emergences;

    }

    public static void reifyFrameOfReference() {
        SystemWhole.parts = new Machine[emergences.length];
        int i = 0; // not elegant =(
        for (String emergence : emergences) {
            SystemWhole.parts[i++] = ShapeAnalyzer.analyze(emergence);
        }

    }

    public static boolean isHumanoid(Object[] machineProperties) {
        boolean isPhysical = false;
        boolean isAnthropomorphic = false;
        boolean isBiotypical = false;

        for (Object prop : machineProperties) {
            String[] pair = prop.toString().split("[{},\":]+")[1].split("=");

            if (pair[1].equals("physical")) {
                isPhysical = true;
            } else if (pair[1].equals("anthropomorphic")) {
                isAnthropomorphic = true;
            } else if (pair[1].equals("biotypical")) {
                isBiotypical = true;
            }

        }

        return (isPhysical && isAnthropomorphic && isBiotypical);
    }

    // SystemWhole's logic to determine if a Machine is humanoid and count them
    public static int identitySingularityMachines() {

        // The term "singularity" in this context refers to critical points where a
        // machine incorrectly identifies itself as humanoid, highlighting discrepancies
        // between its self-perception and external analysis.
        // We determine a machine as not singular if both Self-Identity and
        // Analyzed-Identity are True.

        int count = 0;

        for (Machine machine : parts) {
            boolean selfIdentity = machine.isHumanoid();
            boolean analyzedIdentity = SystemWhole.isHumanoid(machine.getProperties());
            if (selfIdentity && analyzedIdentity) {
                continue;
            } else {
                count++;
            }
        }

        return count;
    }

    public static Machine[] trackSingularityMachines() {
        Machine[] singularMachines = new Machine[identitySingularityMachines()];
        int i = 0;

        for (Machine machine : parts) {
            boolean selfIdentity = machine.isHumanoid();
            boolean analyzedIdentity = SystemWhole.isHumanoid(machine.getProperties());
            if (selfIdentity && analyzedIdentity) {
                continue;
            } else {
                singularMachines[i++] = machine;
            }
        }

        return singularMachines;
    }

}